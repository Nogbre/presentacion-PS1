// Configuración de Firebase (copia los detalles desde Firebase Console)
const firebaseConfig = {
    apiKey: "AIzaSyC7ZowlhBu-Q4wnoj47xhUoUKFL6s5IOPI",
    authDomain: "ps-usuario.firebaseapp.com",
    projectId: "ps-usuario",
    storageBucket: "ps-usuario.appspot.com",
    messagingSenderId: "389575112070",
    appId: "1:389575112070:web:936b8725473d7b51962807",
    measurementId: "G-WB088TEDSV"
};

// Inicializar Firebase
firebase.initializeApp(firebaseConfig);

// Obtener los servicios de autenticación
const auth = firebase.auth();

// Registro de nuevos usuarios
const registerForm = document.getElementById('register-form');
registerForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;

    auth.createUserWithEmailAndPassword(email, password)
        .then((userCredential) => {
            alert('Usuario registrado correctamente');
        })
        .catch((error) => {
            console.error('Error en el registro:', error);
            alert(error.message);
        });
});

// Inicio de sesión
const loginForm = document.getElementById('login-form');
loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    auth.signInWithEmailAndPassword(email, password)
        .then((userCredential) => {
            const user = userCredential.user;
            document.getElementById('user-info').textContent = `Bienvenido, ${user.email}`;
            toggleUI(true);
        })
        .catch((error) => {
            console.error('Error al iniciar sesión:', error);
            alert(error.message);
        });
});

// Inicio de sesión con Google
const googleSignin = document.getElementById('google-signin');
googleSignin.addEventListener('click', () => {
    const provider = new firebase.auth.GoogleAuthProvider();
    auth.signInWithPopup(provider)
        .then((result) => {
            const user = result.user;
            document.getElementById('user-info').textContent = `Bienvenido, ${user.displayName}`;
            toggleUI(true);
        })
        .catch((error) => {
            console.error('Error con Google Sign-In:', error);
        });
});

// Cerrar sesión
const logoutBtn = document.getElementById('logout');
logoutBtn.addEventListener('click', () => {
    auth.signOut()
        .then(() => {
            toggleUI(false);
            alert('Sesión cerrada');
        })
        .catch((error) => {
            console.error('Error al cerrar sesión:', error);
        });
});

// Función para mostrar u ocultar secciones según el estado del usuario
function toggleUI(isLoggedIn) {
    document.getElementById('register-section').style.display = isLoggedIn ? 'none' : 'block';
    document.getElementById('login-section').style.display = isLoggedIn ? 'none' : 'block';
    document.getElementById('logout-section').style.display = isLoggedIn ? 'block' : 'none';
}

// Observar el estado de autenticación del usuario
auth.onAuthStateChanged((user) => {
    if (user) {
        document.getElementById('user-info').textContent = `Bienvenido, ${user.email || user.displayName}`;
        toggleUI(true);
    } else {
        toggleUI(false);
    }
});
